# read in a small vcf (don't use for large vcf files)
read_vcf <- function(input_file) {
  header <- readLines(input_file)
  header <- header[grep('^#C', header)]
  header <- strsplit(header, "\t")[[1]]
  vcf <- read.table(input_file, header=F)
  colnames(vcf) <- header
  return(vcf)
}

# remove all non-genotype information and remove any sites that are 
# not either invariant or biallelic
simplify_vcf <- function(filename) {
  temp_file <- filename
  
  # remove sites that are not either invariant or bi-allelic SNPs
  temp_file <- temp_file[nchar(temp_file[,4]) == 1 & nchar(temp_file[,5]) == 1, ]
  
  # keep only genotype information
  for(a in 10:ncol(temp_file)) {
    temp_file[,a] <- sapply(strsplit(temp_file[,a], ":"), "[[", 1)
  }
  
  # remove phasing information
  for(a in 10:ncol(temp_file)) {
    temp_file[,a] <- gsub("\\|", "/", temp_file[,a])
  }
  return(temp_file)
}


# function to determine if a site is polymorphic (to be applied across rows)
# used in pi_tajima_theta function
polymorphic_function <- function(xxx) {
  return(length(unique(xxx)))
}
# function to determine frequency of allele 1 (to be applied across rows)
# used in pi_tajima_theta function
p_function <- function(xxx) {
  xxxx <- c(sapply(strsplit(xxx, "/"), "[[", 1), sapply(strsplit(xxx, "/"), "[[", 2))
  xxxx <- length(xxxx[xxxx == 0])
  return(xxxx)
}
# function to determine frequency of allele 2 (to be applied across rows)
# used in pi_tajima_theta function
q_function <- function(xxx) {
  xxxx <- c(sapply(strsplit(xxx, "/"), "[[", 1), sapply(strsplit(xxx, "/"), "[[", 2))
  xxxx <- length(xxxx[xxxx == 1])
  return(xxxx)
}

# input is vcf output from simplify_vcf function
# only calculate for invariant sites and biallelic snps
# no missing data allowed
# estimate nucleotide diversity with the formula from 
# Carlson et al. 2005: 10.1101/gr.4326505 (equation 2)

# estimate pi for a population 
estimate_pi_within <- function(xxx) {
  options(scipen=999)

  # remove sites with missing data
  for(a in 10:ncol(xxx)) {
    xxx <- xxx[xxx[,a] != "./.",]
  }
  
  # define number of chromosomes sampled
  n_chromosomes <- (ncol(xxx) - 9) * 2
  # define number of sites genotyped for this population without missing data
  n_sites <- nrow(xxx)
  
  # continue if there are sites genotyped
  if(n_sites > 0) {
    # subset to only polymorphic sites
    xxx <- xxx[apply(xxx[,10:ncol(xxx)], 1, polymorphic_function) > 1, ]
    
    # count polymorphic sites
    n_polymorphic <- nrow(xxx)
    
    # continue if there are polymorphic sites
    if(n_polymorphic > 0) {

      # calculate frequencies of alleles 1 and 2 for each polymorphic site
      p_freq <- as.vector(apply(xxx[,10:ncol(xxx)], 1, p_function)) / n_chromosomes
      q_freq <- as.vector(apply(xxx[,10:ncol(xxx)], 1, q_function)) / n_chromosomes
      
      # calculate per site nucleotide diversity (pi)
      pi <- sum(2 * p_freq * q_freq) * (n_chromosomes / (n_chromosomes - 1)) / n_sites
      
      output <- c(as.integer(n_sites), as.integer(n_polymorphic), pi)
      names(output) <- c("n_sites", "n_polymorphic", "pi")
      return(output)
      
    } else { # if no polymorphic sites retained
      output <- c(n_sites, 0, 0)
      names(output) <- c("n_sites", "n_polymorphic", "pi")
      return(output)
    }
  } else { # if no sites retained
    output <- c(0, 0, 0)
    names(output) <- c("n_sites", "n_polymorphic", "pi")
    return(output)
  }
  
}

# estimate pi for all populations in a popmap
pi_all_pops <- function(vcf, popmap) {
  populations <- unique(popmap[,2])
  # loop for each population
  for(a in 1:length(populations)) {
    a_rep <- vcf[,c(1:9, match(popmap[popmap[,2] == populations[a],1], colnames(vcf)))]
    
    # remove sites with missing data
    for(b in 10:ncol(a_rep)) {
      a_rep <- a_rep[a_rep[,b] != "./.",]
    }
    
    # estimate diversity
    a_temp <- estimate_pi_within(a_rep)
    
    if(a == 1) {
      a_output <- a_temp
    } else {
      a_output <- rbind(a_output, a_temp)
    }
  }
  a_output <- data.frame(Population=as.character(populations), n_sites=as.numeric(a_output[,1]), 
                         n_polymorphic=as.numeric(a_output[,2]), pi=as.numeric(a_output[,3]))
  return(a_output)
}


# estimate pi in sliding windows using pi_all_pops and estimate_pi_within functions
pi_windows <- function(vcf, popmap, window_size) {
  vcf_rep <- vcf
  
  #determine number of windows to calculate
  n_windows <- ceiling(max(vcf_rep$POS) / window_size)
  
  chromosome <- list()
  start <- list()
  end <- list()
  output <- list()
  for(a in 1:n_windows) {
    # subset vcf
    start_rep <-  a * window_size + 1 - window_size
    end_rep <- a * window_size
    a_rep <- vcf_rep[vcf$POS >= start_rep & vcf$POS <= end_rep,]
    
    # calculate diversity
    a_output <- pi_all_pops(a_rep, popmap)
    
    # add to output if there is output
    if(nrow(a_output) > 0) {
      chromosome[[a]] <- rep(a_rep[1,1], nrow(a_output))
      end[[a]] <- rep(end_rep, nrow(a_output))
      start[[a]] <- rep(start_rep, nrow(a_output))
      output[[a]] <- a_output
    }
  }
  
  # combine all output
  output_diversity <- do.call("rbind", output)
  total_output <- data.frame(chromosome=as.character(unlist(chromosome)), start=as.numeric(unlist(start)),
                             end=as.numeric(unlist(end)), population=as.character(output_diversity[,1]), 
                             n_sites=as.numeric(output_diversity[,2]), n_polymorphic=as.numeric(output_diversity[,3]),
                             pi=as.numeric(output_diversity[,4]))
  
  return(total_output)
}

















