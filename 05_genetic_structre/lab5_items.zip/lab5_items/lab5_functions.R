# read in a small vcf (don't use for large vcf files)
read_vcf <- function(input_file) {
  header <- readLines(input_file)
  header <- header[grep('^#C', header)]
  header <- strsplit(header, "\t")[[1]]
  vcf <- read.table(input_file, header=F)
  colnames(vcf) <- header
  return(vcf)
}

# remove all non-genotype information and remove any sites that are 
# not either invariant or biallelic
simplify_vcf <- function(filename) {
  temp_file <- filename
  
  # remove sites that are not either invariant or bi-allelic SNPs
  temp_file <- temp_file[nchar(temp_file[,4]) == 1 & nchar(temp_file[,5]) == 1, ]
  
  # keep only genotype information
  for(a in 10:ncol(temp_file)) {
    temp_file[,a] <- sapply(strsplit(temp_file[,a], ":"), "[[", 1)
  }
  
  # remove phasing information
  for(a in 10:ncol(temp_file)) {
    temp_file[,a] <- gsub("\\|", "/", temp_file[,a])
  }
  return(temp_file)
}


# function to determine if a site is polymorphic (to be applied across rows)
# used in pi_tajima_theta function
polymorphic_function <- function(xxx) {
  return(length(unique(xxx)))
}
# function to determine frequency of allele 1 (to be applied across rows)
# used in pi_tajima_theta function
p_function <- function(xxx) {
  xxxx <- c(sapply(strsplit(xxx, "/"), "[[", 1), sapply(strsplit(xxx, "/"), "[[", 2))
  xxxx <- length(xxxx[xxxx == 0])
  return(xxxx)
}
# function to determine frequency of allele 2 (to be applied across rows)
# used in pi_tajima_theta function
q_function <- function(xxx) {
  xxxx <- c(sapply(strsplit(xxx, "/"), "[[", 1), sapply(strsplit(xxx, "/"), "[[", 2))
  xxxx <- length(xxxx[xxxx == 1])
  return(xxxx)
}

# input is vcf output from simplify_vcf function
# only calculate for invariant sites and biallelic snps
# no missing data allowed
# estimate nucleotide diversity with the formula from 
# Carlson et al. 2005: 10.1101/gr.4326505 (equation 2)

# estimate pi for a population 
estimate_pi_within <- function(xxx) {
  options(scipen=999)

  # remove sites with missing data
  for(a in 10:ncol(xxx)) {
    xxx <- xxx[xxx[,a] != "./.",]
  }
  
  # define number of chromosomes sampled
  n_chromosomes <- (ncol(xxx) - 9) * 2
  # define number of sites genotyped for this population without missing data
  n_sites <- nrow(xxx)
  
  # continue if there are sites genotyped
  if(n_sites > 0) {
    # subset to only polymorphic sites
    xxx <- xxx[apply(xxx[,10:ncol(xxx)], 1, polymorphic_function) > 1, ]
    
    # count polymorphic sites
    n_polymorphic <- nrow(xxx)
    
    # continue if there are polymorphic sites
    if(n_polymorphic > 0) {

      # calculate frequencies of alleles 1 and 2 for each polymorphic site
      p_freq <- as.vector(apply(xxx[,10:ncol(xxx)], 1, p_function)) / n_chromosomes
      q_freq <- as.vector(apply(xxx[,10:ncol(xxx)], 1, q_function)) / n_chromosomes
      
      # calculate per site nucleotide diversity (pi)
      pi <- sum(2 * p_freq * q_freq) * (n_chromosomes / (n_chromosomes - 1)) / n_sites
      
      output <- c(as.integer(n_sites), as.integer(n_polymorphic), pi)
      names(output) <- c("n_sites", "n_polymorphic", "pi")
      return(output)
      
    } else { # if no polymorphic sites retained
      output <- c(n_sites, 0, 0)
      names(output) <- c("n_sites", "n_polymorphic", "pi")
      return(output)
    }
  } else { # if no sites retained
    output <- c(0, 0, 0)
    names(output) <- c("n_sites", "n_polymorphic", "pi")
    return(output)
  }
  
}

# estimate pi for all populations in a popmap
pi_all_pops <- function(vcf, popmap) {
  populations <- unique(popmap[,2])
  # loop for each population
  for(a in 1:length(populations)) {
    a_rep <- vcf[,c(1:9, match(popmap[popmap[,2] == populations[a],1], colnames(vcf)))]
    
    # remove sites with missing data
    for(b in 10:ncol(a_rep)) {
      a_rep <- a_rep[a_rep[,b] != "./.",]
    }
    
    # estimate diversity
    a_temp <- estimate_pi_within(a_rep)
    
    if(a == 1) {
      a_output <- a_temp
    } else {
      a_output <- rbind(a_output, a_temp)
    }
  }
  a_output <- data.frame(Population=as.character(populations), n_sites=as.numeric(a_output[,1]), 
                         n_polymorphic=as.numeric(a_output[,2]), pi=as.numeric(a_output[,3]))
  return(a_output)
}


# estimate pi in sliding windows using pi_all_pops and estimate_pi_within functions
pi_windows <- function(vcf, popmap, window_size) {
  vcf_rep <- vcf
  
  #determine number of windows to calculate
  n_windows <- ceiling(max(vcf_rep$POS) / window_size)
  
  chromosome <- list()
  start <- list()
  end <- list()
  output <- list()
  for(a in 1:n_windows) {
    # subset vcf
    start_rep <-  a * window_size + 1 - window_size
    end_rep <- a * window_size
    a_rep <- vcf_rep[vcf$POS >= start_rep & vcf$POS <= end_rep,]
    
    # calculate diversity
    a_output <- pi_all_pops(a_rep, popmap)
    
    # add to output if there is output
    if(nrow(a_output) > 0) {
      chromosome[[a]] <- rep(a_rep[1,1], nrow(a_output))
      end[[a]] <- rep(end_rep, nrow(a_output))
      start[[a]] <- rep(start_rep, nrow(a_output))
      output[[a]] <- a_output
    }
  }
  
  # combine all output
  output_diversity <- do.call("rbind", output)
  total_output <- data.frame(chromosome=as.character(unlist(chromosome)), start=as.numeric(unlist(start)),
                             end=as.numeric(unlist(end)), population=as.character(output_diversity[,1]), 
                             n_sites=as.numeric(output_diversity[,2]), n_polymorphic=as.numeric(output_diversity[,3]),
                             pi=as.numeric(output_diversity[,4]))
  
  return(total_output)
}









# function to determine if a site is only missing data for a population (used across rows of vcf)
# used in differentiation function
total_missing <- function(xxx) {
	return(length(xxx[xxx != "./."]) > 0)
}			
# function to determine if a site is polymorphic (to be applied across rows) after removing missing
# used in differentiation function
polymorphic_function2 <- function(xxx) {
	xxx <- xxx[xxx != "./."]
	return(length(unique(xxx)))
}			

# input is two simplified vcfs (subsampled to single population), already filtered for invariant/biallelic SNPs, 
# the names of the populations, and output file name
# and the input simple vcf file name that contains the chr and start and end information
# only calculate for invariant sites and biallelic snps
# fst is calculation of Reich et al. 2009
# fst is the reich et al. 2009 estimator for small sample sizes
# equation presented nicer in Willing et al. 2012 page 9

# estimate fst or dxy for all population comparisons in a popmap
differentiation_all_pops <- function(vcf, popmap, stat) {
  populations <- unique(popmap[,2])
  
  # calculate differentiation statistics for each pairwise comparison
	all_combinations <- combn(populations, 2)
	for(a in 1:ncol(all_combinations)) {
		# define populations
		a_pop1 <- all_combinations[1,a]
		a_pop2 <- all_combinations[2,a]
	
		# subset vcf inputs
		a_input1 <- vcf[,colnames(vcf) %in% popmap[popmap$Population == a_pop1,1]]
		a_input2 <- vcf[,colnames(vcf) %in% popmap[popmap$Population == a_pop2,1]]
	
		if(stat == "fst") {
			# estimate fst
    		a_temp <- fst_calc(a_input1, a_input2, a_pop1, a_pop2)
    
    		if(a == 1) {
      			a_output <- a_temp
    		} else {
     			a_output <- rbind(a_output, a_temp)
   			}
		}
		if(stat == "dxy") {
			# estimate fst
    		a_temp <- dxy_calc(a_input1, a_input2, a_pop1, a_pop2)
    
    		if(a == 1) {
      			a_output <- a_temp
    		} else {
     			a_output <- rbind(a_output, a_temp)
   			}
		}
	}
		if(stat == "fst") { 
			a_output <- data.frame(Population1=as.character(all_combinations[1,]), 
									Population2=as.character(all_combinations[2,]), 
									n_sites=as.numeric(a_output[,1]), n_polymorphic=as.numeric(a_output[,2]), 
									fst=as.numeric(a_output[,3]))
  			return(a_output)
		}
		
		if(stat == "dxy") { 
			a_output <- data.frame(Population1=as.character(all_combinations[1,]), 
									Population2=as.character(all_combinations[2,]), 
									n_sites=as.numeric(a_output[,1]), n_polymorphic=as.numeric(a_output[,2]), 
									dxy=as.numeric(a_output[,3]))
  			return(a_output)
		}
	
}



fst_calc <- function(xxx1, xxx2, popname1, popname2) {
	
	# remove sites that are completely missing from either population
	keep1 <- apply(xxx1, 1, total_missing)
	keep2 <- apply(xxx2, 1, total_missing)
	xxx1 <- xxx1[keep1 == TRUE & keep2 == TRUE, ]
	xxx2 <- xxx2[keep1 == TRUE & keep2 == TRUE, ]
	
	# count the total number of included genotyped sites at this point
	n_sites <- nrow(xxx1)
	
	# combine the two matrices to find sites that are variant w/in and between the two pops
	xxx_combined <- cbind(xxx1, xxx2)
	variant_sites <- apply(xxx_combined, 1, polymorphic_function2)
	
	# keep only variant sites
	xxx1_variant <- xxx1[variant_sites > 1, ]
	xxx2_variant <- xxx2[variant_sites > 1, ]
	
	# count the number of variant sites
	n_variant_sites <- nrow(xxx1_variant)
	
	# loop for each polymorphic site to calculate fst
	numerator_all <- list()
	denominator_all <- list()
	for(a in 1:nrow(xxx1_variant)) {
		a_rep1 <- as.character(xxx1_variant[a,])
		a_rep2 <- as.character(xxx2_variant[a,])
		
		# remove missing
		a_rep1 <- a_rep1[a_rep1 != "./."]
		a_rep2 <- a_rep2[a_rep2 != "./."]

		# number of individuals per population
		pop1_ind_count <- length(a_rep1) 
		pop2_ind_count <- length(a_rep2)
		
		# non-reference allele counts
		alt_allele_count1 <- (2 * length(a_rep1[a_rep1 == "1/1"]) + 1 * length(a_rep1[a_rep1 == "0/1"]))
		alt_allele_count2 <- (2 * length(a_rep2[a_rep2 == "1/1"]) + 1 * length(a_rep2[a_rep2 == "0/1"]))

		# total allele counts
		all_allele_count1 <- 2 * length(a_rep1)
		all_allele_count2 <- 2 * length(a_rep2)

		# expected heterozygosity for each population
		expected_het1 <- (alt_allele_count1 * (all_allele_count1 - alt_allele_count1)) / 
			(all_allele_count1 * (all_allele_count1 - 1))
		expected_het2 <- (alt_allele_count2 * (all_allele_count2 - alt_allele_count2)) / 
			(all_allele_count2 * (all_allele_count2 - 1))

		# find the fst numerator and denominator values for this snp (they all get summed and divided for 
		# the final estimate)
		numerator_all[[a]] <- (alt_allele_count1 / (2 * pop1_ind_count) - 
			alt_allele_count2 / (2 * pop2_ind_count))^2 - (expected_het1 / (2 * pop1_ind_count)) - 
			(expected_het2 / (2 * pop2_ind_count))
		denominator_all[[a]] <- numerator_all[[a]] + expected_het1 + expected_het2		
	}
	# calculate total fst for this window
	fst_all <- sum(unlist(numerator_all)) / sum(unlist(denominator_all))
	
	output_fst <- c(n_sites, n_variant_sites, fst_all)
	
	return(output_fst)
}


		

dxy_calc <- function(xxx1, xxx2, popname1, popname2) {
	
# remove sites that are completely missing from either population
	keep1 <- apply(xxx1, 1, total_missing)
	keep2 <- apply(xxx2, 1, total_missing)
	xxx1 <- xxx1[keep1 == TRUE & keep2 == TRUE, ]
	xxx2 <- xxx2[keep1 == TRUE & keep2 == TRUE, ]
	
	# count the total number of included genotyped sites at this point
	n_sites <- nrow(xxx1)
	
	# combine the two matrices to find sites that are variant w/in and between the two pops
	xxx_combined <- cbind(xxx1, xxx2)
	variant_sites <- apply(xxx_combined, 1, polymorphic_function2)
	
	# keep only variant sites
	xxx1_variant <- xxx1[variant_sites > 1, ]
	xxx2_variant <- xxx2[variant_sites > 1, ]
	
	# count the number of variant sites
	n_variant_sites <- nrow(xxx1_variant)
	
	# loop for each polymorphic site to calculate dxy
	dxy_all <- list()
	for(a in 1:nrow(xxx1_variant)) {
		a_rep1 <- as.character(xxx1_variant[a,])
		a_rep2 <- as.character(xxx2_variant[a,])
		
		# remove missing
		a_rep1 <- a_rep1[a_rep1 != "./."]
		a_rep2 <- a_rep2[a_rep2 != "./."]
		
		# measure proportion of reference allele 
		a_ref1 <- (length(a_rep1[a_rep1 == "0/0"]) * 2 + length(a_rep1[a_rep1 == "0/1"]) * 1) / (length(a_rep1) * 2)
		a_ref2 <- (length(a_rep2[a_rep2 == "0/0"]) * 2 + length(a_rep2[a_rep2 == "0/1"]) * 1) / (length(a_rep2) * 2)
		
		# calc dxy
		dxy_all[[a]] <- a_ref1 * (1 - a_ref2) + a_ref2 * (1 - a_ref1)
	}
	dxy_all <- sum(unlist(dxy_all)) / n_sites
	

	output_dxy <- c(n_sites, n_variant_sites, dxy_all)
	
	return(output_dxy)
	
}







# estimate differentiation in sliding windows using differentiation_all_pops function
differentiation_windows <- function(vcf, popmap, window_size, stat) {
  vcf_rep <- vcf
  
  #determine number of windows to calculate
  n_windows <- ceiling(max(vcf_rep$POS) / window_size)
  
  chromosome <- list()
  start <- list()
  end <- list()
  output <- list()
  for(a in 1:n_windows) {
    # subset vcf
    start_rep <-  a * window_size + 1 - window_size
    end_rep <- a * window_size
    a_rep <- vcf_rep[vcf$POS >= start_rep & vcf$POS <= end_rep,]
    
    # calculate diversity
    a_output <- differentiation_all_pops(a_rep, popmap, stat)
    
    # add to output if there is output
    if(nrow(a_output) > 0) {
      chromosome[[a]] <- rep(a_rep[1,1], nrow(a_output))
      end[[a]] <- rep(end_rep, nrow(a_output))
      start[[a]] <- rep(start_rep, nrow(a_output))
      output[[a]] <- a_output
    }
  }
  
  # combine all output
  output_diff <- do.call("rbind", output)
  if(stat == "fst") {
  	total_output <- data.frame(chromosome=as.character(unlist(chromosome)), start=as.numeric(unlist(start)),
                             end=as.numeric(unlist(end)), population1=as.character(output_diff[,1]), 
                             population2=as.character(output_diff[,2]),
                             n_sites=as.numeric(output_diff[,3]), n_polymorphic=as.numeric(output_diff[,4]),
                             fst=as.numeric(output_diff[,5]))
  } 
  if(stat == "dxy") {
  	total_output <- data.frame(chromosome=as.character(unlist(chromosome)), start=as.numeric(unlist(start)),
                             end=as.numeric(unlist(end)), population1=as.character(output_diff[,1]), 
                             population2=as.character(output_diff[,2]),
                             n_sites=as.numeric(output_diff[,3]), n_polymorphic=as.numeric(output_diff[,4]),
                             dxy=as.numeric(output_diff[,5]))
  }
  
  
  return(total_output)
}












